export class TempContractBoxModel {
  constructor(public Code: string,
              public Title: string,
              public PM: string,
              public PMCode: string,
              public Status: string,
              public Picture: string,
              public Date: string,
              public IsSpecial: boolean,) {
  }
}
