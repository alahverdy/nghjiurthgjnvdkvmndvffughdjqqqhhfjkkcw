export class PostLikesModel {
  constructor(public ID: number,
              public PostId: number) {
  }
}
