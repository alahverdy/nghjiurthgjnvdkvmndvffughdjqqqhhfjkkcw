export class EducationLevelModel {
  constructor(public ID: number,
              public Title: string) {
  }
}
