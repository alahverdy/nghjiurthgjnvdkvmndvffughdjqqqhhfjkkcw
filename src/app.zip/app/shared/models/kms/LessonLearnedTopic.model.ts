export class LessonLearnedTopicModel {
  constructor(public ID: number,
              public Title: string) {
  }
}
