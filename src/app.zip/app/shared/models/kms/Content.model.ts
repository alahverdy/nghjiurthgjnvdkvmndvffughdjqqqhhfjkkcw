export class ContentModel {
  constructor(public ID: number,
              public Title: string,
              public ContentKind: number,
              public Body: any) {
  }
}
