export class LessonLearnedStepModel {
  constructor(public ID: number,
              public Title: string) {
  }
}
