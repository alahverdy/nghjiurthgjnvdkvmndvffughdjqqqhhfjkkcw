export class CurrentUserModel {
  constructor(public Id: number,
              public LoginName: string,
              public IsSiteAdmin: boolean) {
  }
}
