export class FileTypeModel {
  constructor(public ID: number,
              public Title: string) {
  }
}
