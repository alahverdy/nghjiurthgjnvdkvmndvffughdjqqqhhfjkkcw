export class CriteriasModel {
  constructor(public ID: number,
              public Title: string,
              public ScoreWeight: number,) {
  }
}
