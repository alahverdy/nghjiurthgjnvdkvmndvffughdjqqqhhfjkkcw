export class SearchListModel {
  constructor(public ID: number,
              public Title: string) {
  }
}
