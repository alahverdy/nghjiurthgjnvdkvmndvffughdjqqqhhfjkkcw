export class RaiPartsModel {
  constructor(public ID: number,
              public Title: string) {
  }
}
