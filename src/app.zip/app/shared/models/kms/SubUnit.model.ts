export class SubUnitModel {
  constructor(public ID: number,
              public Title: string,
              public Unit: number[]) {
  }
}
