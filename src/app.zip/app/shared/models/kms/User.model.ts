export class UserModel {
  constructor(public ID: number,
              public Title: string,
              public IsUser: boolean) {
  }
}
