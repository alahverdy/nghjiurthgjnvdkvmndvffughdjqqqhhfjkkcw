export class OperationKindModel {
  constructor(public ID: number,
              public Title: string) {
  }
}
