export class ContractorModel {
  constructor(public ID: number,
              public Title: string) {
  }
}
