export class FileModel {
  constructor(public Name: string,
              public ServerRelativeUrl: string) {
  }
}
