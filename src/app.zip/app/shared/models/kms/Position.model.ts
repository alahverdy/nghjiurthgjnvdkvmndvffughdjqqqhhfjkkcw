export class PositionModel {
  constructor(public ID: number,
              public Title: string) {
  }
}
