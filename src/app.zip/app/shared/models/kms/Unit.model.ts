export class UnitModel {
  constructor(public ID: number,
              public Title: string) {
  }
}
